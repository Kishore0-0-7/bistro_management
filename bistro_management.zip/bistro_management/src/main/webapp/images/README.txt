Image Directory Structure

/images
  /menu - Contains menu item images
  hero-bg.jpg - Hero section background image
  restaurant.jpg - About section restaurant image
  
Note: For a production environment, you should replace these placeholder images with actual images of your restaurant and menu items.
